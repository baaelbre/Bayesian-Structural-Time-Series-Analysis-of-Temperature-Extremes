from __future__ import annotations

from typing import Sequence

from ..components.base import Component
from ..models.structural import StructuralSSM
from ..obs.gaussian import GaussianObs
from ..obs.gev import GEVObs


def make_gaussian_model(components: Sequence[Component]) -> StructuralSSM:
    """Build a structural model with Gaussian observations."""
    return StructuralSSM(components=list(components), obs=GaussianObs(), eta_name="mu")


def make_gev_model(components: Sequence[Component]) -> StructuralSSM:
    """Build a structural model with GEV observations."""
    return StructuralSSM(components=list(components), obs=GEVObs(), eta_name="mu")
