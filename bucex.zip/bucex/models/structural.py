from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np

from ..components.base import Component
from ..components.compose import compose_components, compose_initial_state
from .base import LinearDesign, LinearGaussianSystem, StateSpaceModel

Array = np.ndarray
ParamDict = Dict[str, Any]


@dataclass
class StructuralSSM(StateSpaceModel):
    """
    Structural state space model = structural components + observation model.

    - Components define latent evolution blocks and linear predictor contributions.
    - compose_components(...) stacks them into global matrices (T, R, Q, c, Z, d).
    - obs_params(...) maps eta_t to the observation model parameter dict.

    For now the default mapping is:
        eta_t -> {"mu": eta_t, ...params_obs}
    which works for:
      - GaussianObs with params_obs={"sigma": ...}
      - GEVObs      with params_obs={"sigma": ..., "xi": ...}

    Later this can be extended to multiple predictors, links, time-varying scale, etc.
    """
    components: Sequence[Component]
    obs: Any
    eta_name: str = "mu"

    def __post_init__(self) -> None:
        self._state_names = tuple(
            name
            for comp in self.components
            for name in comp.spec.state_names
        )
        self._m = len(self._state_names)

    @property
    def state_dim(self) -> int:
        return self._m

    @property
    def eta_dim(self) -> int:
        # current components return a scalar linear predictor
        return 1

    @property
    def state_names(self) -> Tuple[str, ...]:
        return self._state_names

    def initial_state(self, params_state: ParamDict) -> Tuple[Array, Array]:
        """
        Return global prior mean and covariance for x_0 by stacking the
        component-specific initial states.
        """
        return compose_initial_state(self.components, params_state)

    def system(self, t: int, params_state: ParamDict) -> LinearGaussianSystem:
        mats = compose_components(self.components, t=t, params=params_state)
        return LinearGaussianSystem(
            T=mats.T,
            R=mats.R,
            Q=mats.Q,
            c=mats.c,
        )

    def design(
        self,
        t: int,
        params_state: ParamDict,
        exog_t: Optional[Array] = None,
    ) -> LinearDesign:
        # exog_t is ignored for now, but we keep it in the signature
        # so regression components can use it later if needed.
        mats = compose_components(self.components, t=t, params=params_state)
        return LinearDesign(
            Z=mats.Z,
            d=mats.d,
        )

    def obs_params(
        self,
        t: int,
        x_t: Array,
        eta_t: Array,
        params_obs: ParamDict,
        exog_t: Optional[Array] = None,
    ) -> Dict[str, Any]:
        """
        Default observation-parameter mapping.

        Example
        -------
        Gaussian:
            params_obs={"sigma": 1.0}
            -> {"mu": eta_t, "sigma": 1.0}

        GEV:
            params_obs={"sigma": 1.2, "xi": -0.2}
            -> {"mu": eta_t, "sigma": 1.2, "xi": -0.2}
        """
        out = dict(params_obs)
        out[self.eta_name] = float(np.atleast_1d(eta_t)[0])
        return out

# User-facing alias for the high-level API
StructuralModel = StructuralSSM
