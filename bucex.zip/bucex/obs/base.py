# src/sts_extremes/obs/base.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Protocol, Tuple
import numpy as np


class ObservationModel(Protocol):
    """
    Observation model for y_t given a 1D predictor eta_t (mu_t in BSTS1).

    Required:
      - logpdf(y, eta, params)
      - sample(eta, params, rng)

    Optional (for Laplace etc. later):
      - grad_eta(y, eta, params)   d/d eta log p(y|eta)
      - hess_eta(y, eta, params)   d^2/d eta^2 log p(y|eta)
    """

    def logpdf(self, y: float, eta: float, params: Dict[str, float]) -> float: ...
    def sample(self, eta: float, params: Dict[str, float], rng: np.random.Generator) -> float: ...

    def grad_eta(self, y: float, eta: float, params: Dict[str, float]) -> float: ...
    def hess_eta(self, y: float, eta: float, params: Dict[str, float]) -> float: ...


@dataclass(frozen=True)
class ObsSpec:
    name: str