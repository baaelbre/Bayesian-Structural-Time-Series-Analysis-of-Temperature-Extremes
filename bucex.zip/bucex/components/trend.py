from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple
import numpy as np
from scipy.linalg import block_diag

from .base import ComponentSpec


@dataclass
class LocalLinearTrend:
    """
    Combined level+slope (LLT) block.

    State (dynamic parts only):
      [alpha] if level_mode=="dynamic"
      [beta ] if trend_mode=="dynamic"

    Dynamics:
      alpha_t = alpha_{t-1} + (beta_{t-1} if trend_mode dynamic else fixed_trend or 0) + e_level
      beta_t  = beta_{t-1} + e_trend
      e_level ~ N(0,Q_level), e_trend ~ N(0,Q_trend)

    Observation (mu):
      mu_t += alpha_t (if alpha dynamic) or
      mu_t += fixed_level + fixed_trend*t (if level static)
    """
    level_mode: str = "dynamic"  # "dynamic" | "static"
    trend_mode: str = "dynamic"  # "dynamic" | "static" | "off"

    def __post_init__(self) -> None:
        if self.level_mode not in {"dynamic", "static"}:
            raise ValueError("level_mode must be 'dynamic' or 'static'.")
        if self.trend_mode not in {"dynamic", "static", "off"}:
            raise ValueError("trend_mode must be 'dynamic', 'static', or 'off'.")

        names = []
        if self.level_mode == "dynamic":
            names.append("alpha")
        if self.trend_mode == "dynamic":
            names.append("beta")

        self.spec = ComponentSpec(
            name="llt",
            mode="dynamic" if names else "static",
            state_dim=len(names),
            noise_dim=len(names),
            state_names=tuple(names),
        )

    def initial_mean_var(self, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        if self.spec.state_dim == 0:
            return np.zeros(0), np.zeros(0)

        m0, v0 = [], []
        if self.level_mode == "dynamic":
            m0.append(float(params.get("m0_level", 0.0)))
            v0.append(float(params.get("v0_level", 1.0)))
        if self.trend_mode == "dynamic":
            m0.append(float(params.get("m0_trend", 0.0)))
            v0.append(float(params.get("v0_trend", 1.0)))
        v0 = np.asarray(v0, float)
        if np.any(v0 < 0.0):
            raise ValueError("Initial variances must be >=0.")
        return np.asarray(m0, float), v0

    def system_matrices(self, t: int, params: Dict[str, float]):
        m = self.spec.state_dim
        if m == 0:
            return np.zeros((0, 0)), np.zeros((0, 0)), np.zeros((0, 0)), np.zeros((0,))

        # default RW blocks per latent coord
        T = np.eye(m)
        R = np.eye(m)
        c = np.zeros(m)

        q = []
        if self.level_mode == "dynamic":
            q.append(float(params.get("q_level", 0.0)))
        if self.trend_mode == "dynamic":
            q.append(float(params.get("q_trend", 0.0)))
        q = np.asarray(q, float)
        if np.any(q < 0.0):
            raise ValueError("q_* must be >=0.")
        Q = np.diag(q)

        # coupling alpha <- beta, or deterministic drift into alpha
        if self.level_mode == "dynamic":
            ia = 0
            if self.trend_mode == "dynamic":
                ib = 1 if self.level_mode == "dynamic" else 0
                T[ia, ib] = 1.0
            elif self.trend_mode == "static":
                c[ia] = float(params.get("fixed_trend", 0.0))

        return T, R, Q, c

    def design_matrices(self, t: int, params: Dict[str, float]):
        m = self.spec.state_dim
        Z = np.zeros((1, m))
        d = np.zeros((1,))

        if self.level_mode == "dynamic":
            Z[0, 0] = 1.0
        else:
            d[0] += float(params.get("fixed_level", 0.0))
            if self.trend_mode == "static":
                d[0] += float(params.get("fixed_trend", 0.0)) * float(t)

        return Z, d