from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.linalg import block_diag

from .base import Component

Array = np.ndarray


@dataclass(frozen=True)
class ComposedMatrices:
    """
    Global matrices obtained by stacking component-specific blocks.

    State evolution:
        x_t = T x_{t-1} + c + R eps_t,   eps_t ~ N(0, Q)

    Linear predictor:
        eta_t = Z x_t + d
    """
    T: Array
    R: Array
    Q: Array
    c: Array
    Z: Array
    d: Array
    state_names: Tuple[str, ...]


def _blkdiag_rect(mats: List[Array]) -> Array:
    """
    Block diagonal concatenation for rectangular matrices.
    """
    m_tot = sum(A.shape[0] for A in mats)
    r_tot = sum(A.shape[1] for A in mats)

    out = np.zeros((m_tot, r_tot), dtype=float)
    i = 0
    j = 0
    for A in mats:
        m_k, r_k = A.shape
        out[i:i + m_k, j:j + r_k] = A
        i += m_k
        j += r_k
    return out


def compose_initial_state(
    components: Sequence[Component],
    params: Dict[str, float],
) -> Tuple[Array, Array]:
    """
    Stack component-specific initial means and diagonal variances into
    a global Gaussian prior:

        x_0 ~ N(m0, P0)

    Each component provides:
        (m0_k, v0diag_k)

    and we build:
        m0 = concat_k m0_k
        P0 = blockdiag_k diag(v0diag_k)
    """
    m0_blocks: List[Array] = []
    P0_blocks: List[Array] = []

    for comp in components:
        if comp.spec.state_dim == 0:
            continue

        m0_k, v0_k = comp.initial_mean_var(params)
        m0_k = np.asarray(m0_k, dtype=float).reshape(comp.spec.state_dim)
        v0_k = np.asarray(v0_k, dtype=float).reshape(comp.spec.state_dim)

        if np.any(v0_k < 0.0):
            raise ValueError(f"Negative initial variance in component '{comp.spec.name}'.")

        m0_blocks.append(m0_k)
        P0_blocks.append(np.diag(v0_k))

    if m0_blocks:
        m0 = np.concatenate(m0_blocks)
        P0 = block_diag(*P0_blocks)
    else:
        m0 = np.zeros((0,), dtype=float)
        P0 = np.zeros((0, 0), dtype=float)

    return m0, P0


def compose_components(
    components: Sequence[Component],
    t: int,
    params: Dict[str, float],
) -> ComposedMatrices:
    """
    Compose all component blocks into one global state-space system at time t.
    """
    Tblk: List[Array] = []
    Rblk: List[Array] = []
    Qblk: List[Array] = []
    cblk: List[Array] = []
    Zblk: List[Array] = []

    d = np.zeros((1,), dtype=float)
    names: List[str] = []

    for comp in components:
        Zk, dk = comp.design_matrices(t, params)
        Zk = np.asarray(Zk, dtype=float)
        dk = np.asarray(dk, dtype=float).reshape(1)
        d += dk

        if comp.spec.state_dim == 0:
            continue

        Tk, Rk, Qk, ck = comp.system_matrices(t, params)

        Tk = np.asarray(Tk, dtype=float)
        Rk = np.asarray(Rk, dtype=float)
        Qk = np.asarray(Qk, dtype=float)
        ck = np.asarray(ck, dtype=float).reshape(comp.spec.state_dim)

        Tblk.append(Tk)
        Rblk.append(Rk)
        Qblk.append(Qk)
        cblk.append(ck)
        Zblk.append(Zk)
        names.extend(comp.spec.state_names)

    T = block_diag(*Tblk) if Tblk else np.zeros((0, 0), dtype=float)
    Q = block_diag(*Qblk) if Qblk else np.zeros((0, 0), dtype=float)
    R = _blkdiag_rect(Rblk) if Rblk else np.zeros((0, 0), dtype=float)
    c = np.concatenate(cblk) if cblk else np.zeros((0,), dtype=float)
    Z = np.concatenate(Zblk, axis=1) if Zblk else np.zeros((1, 0), dtype=float)

    return ComposedMatrices(
        T=T,
        R=R,
        Q=Q,
        c=c,
        Z=Z,
        d=d,
        state_names=tuple(names),
    )