# src/sts_extremes/components/seasonal.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple
import numpy as np

from .base import ComponentSpec


@dataclass
class DummySeasonal:
    """
    Dummy seasonal with sum-to-zero closure.

    mode:
      - "dynamic": state length (p-1), newest-first, 1 innovation
      - "static":  offset season_vec[t % p]
      - "off":     0

    Dynamic transition (m=p-1):
      g1_t = -sum(g_{t-1}) + e_t,  e_t~N(0,q_season)
      gk_t = g_{k-1,t-1}, k=2..m
    Observation loads g1_t.
    """
    period: int = 12
    mode: str = "dynamic"  # "dynamic" | "static" | "off"

    def __post_init__(self) -> None:
        if self.period < 2:
            raise ValueError("period must be >=2.")
        if self.mode not in {"dynamic", "static", "off"}:
            raise ValueError("mode must be 'dynamic', 'static', or 'off'.")

        m = (self.period - 1) if self.mode == "dynamic" else 0
        r = 1 if self.mode == "dynamic" else 0
        names = tuple(f"g{k}" for k in range(1, self.period)) if self.mode == "dynamic" else tuple()
        self.spec = ComponentSpec("seasonal", self.mode, m, r, names)

    def initial_mean_var(self, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        if self.mode != "dynamic":
            return np.zeros(0), np.zeros(0)
        m0 = np.asarray(params.get("m0_season", np.zeros(self.period - 1)), float).reshape(-1)
        v0 = np.asarray(params.get("v0_season", np.ones(self.period - 1)), float).reshape(-1)
        if m0.size != self.period - 1 or v0.size != self.period - 1:
            raise ValueError(f"m0_season/v0_season must have length {self.period-1}.")
        if np.any(v0 < 0.0):
            raise ValueError("v0_season must be >=0.")
        return m0, v0

    def system_matrices(self, t: int, params: Dict[str, float]):
        if self.mode != "dynamic":
            return np.zeros((0, 0)), np.zeros((0, 0)), np.zeros((0, 0)), np.zeros((0,))

        m = self.period - 1
        q = float(params.get("q_season", 0.0))
        if q < 0.0:
            raise ValueError("q_season must be >=0.")

        T = np.zeros((m, m))
        T[0, :] = -1.0
        T[1:, :-1] = np.eye(m - 1)

        R = np.zeros((m, 1))
        R[0, 0] = 1.0

        Q = np.asarray([[q]], float)
        c = np.zeros(m)
        return T, R, Q, c

    def design_matrices(self, t: int, params: Dict[str, float]):
        if self.mode == "dynamic":
            Z = np.zeros((1, self.period - 1))
            Z[0, 0] = 1.0
            return Z, np.asarray([0.0])

        if self.mode == "static":
            vec = np.asarray(params.get("season_vec", np.zeros(self.period)), float).reshape(-1)
            if vec.size != self.period:
                raise ValueError(f"season_vec must have length {self.period}.")
            return np.zeros((1, 0)), np.asarray([float(vec[t % self.period])])

        return np.zeros((1, 0)), np.asarray([0.0])