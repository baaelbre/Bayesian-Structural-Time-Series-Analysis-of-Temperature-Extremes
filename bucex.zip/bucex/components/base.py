# src/sts_extremes/components/base.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Protocol, Tuple
import numpy as np

# components can be "dynamic" (with latent state), "static" (no state, but time-varying contribution to eta_t), or "off" (no contribution at all).
Mode = str  # "dynamic" | "static" | "off"

@dataclass(frozen=True)
class ComponentSpec:
    name: str
    mode: Mode
    state_dim: int
    noise_dim: int
    state_names: Tuple[str, ...] = ()


class Component(Protocol):
    """
    Component block for a (linear-Gaussian) latent state space.

      x_t = T x_{t-1} + c + R eps_t,     eps_t ~ N(0, Q)
      mu_t = Z x_t + d

    Shapes (component k):
      T: (m,m), R: (m,r), Q: (r,r), c: (m,)
      Z: (1,m), d: (1,)

    For "static"/"off" components without latent state:
      state_dim = noise_dim = 0, and they contribute only via d(t).
    """
    spec: ComponentSpec

    def initial_mean_var(self, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        """Return (m0, v0diag) for this component's state. Shapes: (m,), (m,)."""

    def system_matrices(self, t: int, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Return (T,R,Q,c)."""

    def design_matrices(self, t: int, params: Dict[str, float]) -> Tuple[np.ndarray, np.ndarray]:
        """Return (Z,d)."""