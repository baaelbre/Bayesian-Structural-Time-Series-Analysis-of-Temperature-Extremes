"""Compatibility namespace for the clearer `bucex.observation` import path.

Internally v0.1 still stores the implementation in `bucex.obs`, but user code can
already import from `bucex.observation`.
"""
from .base import ObservationModel, ObsSpec
from .gaussian import GaussianObs
from .gev import GEVObs
from .links import *

__all__ = ["ObservationModel", "ObsSpec", "GaussianObs", "GEVObs"]
