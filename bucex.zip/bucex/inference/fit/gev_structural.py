from __future__ import annotations

from ...api.fit import fit_gev_structural

__all__ = ["fit_gev_structural"]
