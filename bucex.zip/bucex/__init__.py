"""bucex: Bayesian Unobserved Components for Extremes.

Version 0.1 positions bucex as a modular structural state-space package with
pluggable observation models and interchangeable inference backends.

The current release keeps the latent state evolution linear-Gaussian and treats
Gaussian and GEV observations as first-class observation families.
"""
from __future__ import annotations

from .__about__ import __version__
from .models.structural import StructuralSSM as StructuralModel
from .models.structural import StructuralSSM
from .components.trend import LocalLinearTrend
from .components.seasonal import DummySeasonal
from .obs.gaussian import GaussianObs
from .obs.gev import GEVObs
from .api.fit import fit_bayes, fit_gaussian_structural, fit_gev_structural

__all__ = [
    "__version__",
    "StructuralModel",
    "StructuralSSM",
    "LocalLinearTrend",
    "DummySeasonal",
    "GaussianObs",
    "GEVObs",
    "fit_bayes",
    "fit_gaussian_structural",
    "fit_gev_structural",
]
